@echo off
echo Starting PostgreSQL...
docker compose up -d db
start cmd /k "cd backend && npm install && npm run dev"
start cmd /k "cd frontend && npm install && npm run dev"
echo Open http://localhost:5173 after both terminals are ready.
