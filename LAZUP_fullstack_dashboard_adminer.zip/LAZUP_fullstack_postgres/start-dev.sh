#!/usr/bin/env sh
set -e
docker compose up -d db
( cd backend && npm install && npm run dev ) &
( cd frontend && npm install && npm run dev ) &
wait
