import pg from 'pg';
import 'dotenv/config';
const { Pool, Client } = pg;
export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export async function query(text, params=[]) { return pool.query(text, params); }
export async function createListener(onChange){
  const client = new Client({connectionString:process.env.DATABASE_URL});
  await client.connect(); await client.query('LISTEN lazup_changes');
  client.on('notification', n => { try { onChange(JSON.parse(n.payload)); } catch {} });
  return client;
}
