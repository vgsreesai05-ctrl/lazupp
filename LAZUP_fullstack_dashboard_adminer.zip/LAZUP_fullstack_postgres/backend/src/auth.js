import jwt from 'jsonwebtoken';
export const DOMAIN='@bl.students.amrita.edu';
export const validStudentEmail=e=>typeof e==='string' && e.trim().toLowerCase().endsWith(DOMAIN) && e.trim().toLowerCase().length>DOMAIN.length;
export function sign(user){return jwt.sign({sub:user.id,email:user.email,role:user.role,name:user.full_name},process.env.JWT_SECRET,{expiresIn:'12h'});}
export function requireAuth(req,res,next){const h=req.headers.authorization||'';const raw=h.replace(/^Bearer\s+/i,'')||req.query.token||'';try{req.user=jwt.verify(raw,process.env.JWT_SECRET);next();}catch{return res.status(401).json({error:'Authentication required'});}}
export function requireAdmin(req,res,next){if(req.user?.role!=='admin') return res.status(403).json({error:'Admin access required'});next();}
