-- Registered users (admin SQL access only)
SELECT id, full_name, email, room, role, is_verified, created_at
FROM users ORDER BY created_at DESC;

-- Login audit trail
SELECT email, success, ip, user_agent, created_at
FROM login_events ORDER BY created_at DESC;

-- Login history for one student
-- Replace the email below with the student email you want to inspect.
SELECT email, success, ip, created_at
FROM login_events
WHERE email = 'bl.en.example@bl.students.amrita.edu'
ORDER BY created_at DESC;

-- Requests with requester/helper identities
SELECT r.id, r.title, r.category, r.status,
       requester.email AS requester_email,
       helper.email AS helper_email,
       r.created_at
FROM requests r
JOIN users requester ON requester.id = r.requester_id
LEFT JOIN users helper ON helper.id = r.helper_id
ORDER BY r.created_at DESC;
