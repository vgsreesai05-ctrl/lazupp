# LAZUP Frontend + Admin Dashboard

React + Vite frontend source for the LAZUP full-stack application.

## Run
1. Ensure the LAZUP backend is running at `http://localhost:4000`.
2. In this folder run `npm.cmd install`.
3. Run `npm.cmd run dev`.
4. Open `http://localhost:5173`.


