import express from 'express'; import cors from 'cors'; import helmet from 'helmet'; import bcrypt from 'bcryptjs'; import crypto from 'crypto'; import 'dotenv/config';
import {query,createListener} from './db.js'; import {validStudentEmail,sign,requireAuth,requireAdmin} from './auth.js';
const app=express(); app.use(helmet()); app.use(cors({origin:process.env.FRONTEND_ORIGIN?.split(',')||true})); app.use(express.json({limit:'1mb'}));
const cleanUser=u=>({id:u.id,fullName:u.full_name,email:u.email,room:u.room,role:u.role,phone:u.phone_number||null,alternatePhone:u.alternate_phone||null,trustScore:u.trust_score??80,createdAt:u.created_at});
const asyncRoute=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);
const digitsOnly = value => String(value || '').replace(/\D/g,'');
const normalizePhone = value => String(value || '').trim().replace(/[\s().-]/g,'');
async function ensureFeatureSchema(){
  await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS phone_number varchar(32), ADD COLUMN IF NOT EXISTS alternate_phone varchar(32), ADD COLUMN IF NOT EXISTS trust_score integer NOT NULL DEFAULT 80`);
  await query(`ALTER TABLE requests ADD COLUMN IF NOT EXISTS delivery_mode varchar(20) NOT NULL DEFAULT 'in_campus', ADD COLUMN IF NOT EXISTS quantity integer NOT NULL DEFAULT 1, ADD COLUMN IF NOT EXISTS urgent boolean NOT NULL DEFAULT false, ADD COLUMN IF NOT EXISTS destination_lat double precision, ADD COLUMN IF NOT EXISTS destination_lng double precision, ADD COLUMN IF NOT EXISTS maps_url text`);
  await query(`ALTER TABLE outings ADD COLUMN IF NOT EXISTS stop_at timestamptz`);
  await query(`CREATE TABLE IF NOT EXISTS phone_otp_challenges (id bigserial primary key, phone_number varchar(32) not null, code_hash text, provider_sid text, expires_at timestamptz not null, consumed_at timestamptz, created_at timestamptz not null default now())`);
  await query(`CREATE INDEX IF NOT EXISTS phone_otp_phone_idx ON phone_otp_challenges(phone_number,created_at desc)`); await query(`CREATE TABLE IF NOT EXISTS request_rejections (request_id uuid NOT NULL REFERENCES requests(id) ON DELETE CASCADE, user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(request_id,user_id))`);
}
const calculateTrustScore = ({verified=true,completed=0,ratings=[],cancelled=0}) => Math.max(20,Math.min(100,Math.round((verified?55:35)+Math.min(completed,10)*3+(ratings.length?ratings.reduce((a,b)=>a+b,0)/ratings.length*4:0)-Math.min(cancelled,5)*4)));

async function sendEmailOtp(email,name,code){
 const r=await fetch('https://api.emailjs.com/api/v1.0/email/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({service_id:process.env.EMAILJS_SERVICE_ID,template_id:process.env.EMAILJS_TEMPLATE_ID,user_id:process.env.EMAILJS_PUBLIC_KEY,accessToken:process.env.EMAILJS_PRIVATE_KEY,template_params:{to_email:email,user_name:name||'Amrita Student',name:name||'Amrita Student',passcode:code,otp_code:code,title:'LAZUP verification code',message:`Your LAZUP OTP is ${code}. It expires in 1 minute.`}})}); if(!r.ok) throw new Error(`EmailJS failed: ${await r.text()}`);
}
app.get('/api/health',asyncRoute(async(req,res)=>{await query('select 1');res.json({ok:true,database:'postgresql'});}));

app.get('/',asyncRoute(async(req,res)=>{
 const started=process.uptime();
 const [db,users,requests,outings,posts,logins]=await Promise.all([
  query('select current_database() as name, now() as checked_at'),
  query('select count(*)::int as count from users'),
  query('select count(*)::int as count from requests'),
  query('select count(*)::int as count from outings where leaving_at<=now() and stop_at>now()'),
  query('select count(*)::int as count from community_posts'),
  query('select count(*)::int as count from login_events')
 ]);
 const cards=[['Registered users',users.rows[0].count],['Requests',requests.rows[0].count],['Active outings',outings.rows[0].count],['Community posts',posts.rows[0].count],['Login events',logins.rows[0].count]];
 res.type('html').send(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LAZUP Backend Dashboard</title><style>body{margin:0;background:#f6eee5;color:#351b15;font:15px system-ui,Arial}.wrap{max-width:1050px;margin:38px auto;padding:20px}.hero,.card{background:#fffaf4;border:1px solid #ead9c9;border-radius:18px;padding:22px;margin-bottom:16px}.brand{font-size:30px;font-weight:900;color:#682f24;letter-spacing:2px}.ok{color:#23764c;font-weight:800}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}.card b{display:block;font-size:28px;color:#682f24}.card span{font-size:12px;color:#846c60}.links{display:flex;gap:10px;flex-wrap:wrap}.links a{background:#682f24;color:white;text-decoration:none;border-radius:9px;padding:11px 14px}.meta{color:#846c60;font-size:12px}@media(max-width:600px){.wrap{margin:10px auto;padding:10px}}</style></head><body><div class="wrap"><section class="hero"><div class="brand">LAZUP · BACKEND</div><h1>Backend & PostgreSQL status</h1><p class="ok">● API responding · PostgreSQL connected</p><p class="meta">Database: ${String(db.rows[0].name).replace(/[&<>"]/g,'')} · Uptime: ${Math.floor(started/60)} min · Last checked: ${new Date(db.rows[0].checked_at).toLocaleString()}</p></section><div class="grid">${cards.map(([label,value])=>`<section class="card"><b>${value}</b><span>${label}</span></section>`).join('')}</div><section class="hero"><h2>Open services</h2><div class="links"><a href="http://localhost:5173">LAZUP React UI · 5173</a><a href="/api/health">API health · /api/health</a><a href="http://localhost:8080">PostgreSQL Adminer · 8080</a></div><p class="meta">PostgreSQL itself listens on port 5432. It uses a database protocol, so it is not a browser page. Use Adminer on port 8080 to browse tables and run SQL.</p></section></div></body></html>`);
}));

app.post('/api/auth/send-otp',asyncRoute(async(req,res)=>{
 const email=String(req.body.email||'').trim().toLowerCase();
 if(!validStudentEmail(email)) return res.status(400).json({error:'An Amrita student email ending in @bl.students.amrita.edu is mandatory'});
 const code=String(crypto.randomInt(100000,1000000)), hash=await bcrypt.hash(code,10), ttl=Number(process.env.OTP_TTL_SECONDS||60);
 await query('insert into otp_challenges(email,code_hash,expires_at) values($1,$2,now()+($3||\' seconds\')::interval)',[email,hash,ttl]);
 try { await sendEmailOtp(email,req.body.name,code); } catch(e) { console.error(e); return res.status(502).json({error:'Could not send email OTP. Check EmailJS configuration.'}); }
 res.json({ok:true,expiresIn:ttl});
}));
 
app.post('/api/auth/register',asyncRoute(async(req,res)=>{
 const {name,email:raw,room,password,otp}=req.body, email=String(raw||'').trim().toLowerCase();
 const phone=normalizePhone(req.body.phone), alternatePhone=normalizePhone(req.body.alternatePhone);
 if(!validStudentEmail(email)||!name||!room||String(password||'').length<8||!phone||!alternatePhone) return res.status(400).json({error:'Name, room, Amrita student email, two different phone numbers and an 8+ character password are required'});
 if(!/^\+[1-9]\d{7,14}$/.test(phone)||!/^\+[1-9]\d{7,14}$/.test(alternatePhone)) return res.status(400).json({error:'Both phone numbers must use international format, e.g. +919876543210'}); if(digitsOnly(phone)===digitsOnly(alternatePhone)) return res.status(400).json({error:'Primary and alternate phone numbers must be different'});
 const c=(await query('select * from otp_challenges where email=$1 and consumed_at is null and expires_at>now() order by created_at desc limit 1',[email])).rows[0];
 if(!c||!(await bcrypt.compare(String(otp||''),c.code_hash))) return res.status(400).json({error:'Invalid or expired email OTP. Request a new one.'});
 await query('update otp_challenges set consumed_at=now() where id=$1',[c.id]);
 const ph=await bcrypt.hash(password,12);
 const u=(await query('insert into users(full_name,email,room,password_hash,phone_number,alternate_phone,is_verified,trust_score) values($1,$2,$3,$4,$5,$6,true,80) returning *',[name,email,room,ph,phone,alternatePhone])).rows[0];
 res.status(201).json({token:sign(u),user:cleanUser(u)});
}));
app.post('/api/auth/login',asyncRoute(async(req,res)=>{const email=String(req.body.email||'').trim().toLowerCase(); const u=(await query('select * from users where email=$1',[email])).rows[0]; const ok=!!u&&await bcrypt.compare(String(req.body.password||''),u.password_hash); await query('insert into login_events(user_id,email,success,ip,user_agent) values($1,$2,$3,$4,$5)',[u?.id||null,email,ok,req.ip,req.get('user-agent')]); if(!ok)return res.status(401).json({error:'Invalid email or password'}); res.json({token:sign(u),user:cleanUser(u)});}));
// ---- Forgot / reset password ----
const RESET_TTL_MINUTES=Number(process.env.RESET_TTL_MINUTES||15);
const sha256=v=>crypto.createHash('sha256').update(v).digest('hex');
const frontendUrl=()=>(process.env.FRONTEND_URL||process.env.FRONTEND_ORIGIN?.split(',')[0]||'http://localhost:5173').replace(/\/$/,'');
async function ensureResetTable(){await query(`create table if not exists password_resets(id bigserial primary key,user_id uuid not null references users(id) on delete cascade,token_hash text not null unique,expires_at timestamptz not null,consumed_at timestamptz,created_at timestamptz not null default now())`);await query('create index if not exists password_resets_user_idx on password_resets(user_id,created_at desc)');}
async function sendResetEmail(email,name,link){
 const sharedTemplate=!process.env.EMAILJS_RESET_TEMPLATE_ID;
 const r=await fetch('https://api.emailjs.com/api/v1.0/email/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({service_id:process.env.EMAILJS_SERVICE_ID,template_id:process.env.EMAILJS_RESET_TEMPLATE_ID||process.env.EMAILJS_TEMPLATE_ID,user_id:process.env.EMAILJS_PUBLIC_KEY,accessToken:process.env.EMAILJS_PRIVATE_KEY,template_params:{to_email:email,user_name:name||'Amrita Student',name:name||'Amrita Student',reset_link:link,link,title:'Reset your LAZUP password',message:`Click this link to create a new LAZUP password (valid for ${RESET_TTL_MINUTES} minutes): ${link}`,passcode:sharedTemplate?link:undefined,otp_code:sharedTemplate?link:undefined}})});
 if(!r.ok) throw new Error(`EmailJS failed: ${await r.text()}`);
}
app.post('/api/auth/forgot-password',asyncRoute(async(req,res)=>{
 const email=String(req.body.email||'').trim().toLowerCase();
 const generic={ok:true,message:'If this email is registered, a password reset link has been sent to it.'};
 if(!email||!email.includes('@')) return res.status(400).json({error:'Enter your registered email'});
 const u=(await query('select id,full_name,email from users where email=$1',[email])).rows[0];
 if(!u) return res.json(generic);
 const recent=(await query("select 1 from password_resets where user_id=$1 and created_at>now()-interval '60 seconds' limit 1",[u.id])).rows[0];
 if(recent) return res.status(429).json({error:'A reset email was just sent. Please wait a minute before trying again.'});
 const token=crypto.randomBytes(32).toString('hex');
 await query('update password_resets set consumed_at=now() where user_id=$1 and consumed_at is null',[u.id]);
 await query("insert into password_resets(user_id,token_hash,expires_at) values($1,$2,now()+($3||' minutes')::interval)",[u.id,sha256(token),RESET_TTL_MINUTES]);
 const link=`${frontendUrl()}/?reset_token=${token}`;
 try{await sendResetEmail(u.email,u.full_name,link);}catch(e){console.error(e);return res.status(502).json({error:'Could not send the reset email. Please try again shortly.'});}
 res.json(generic);
}));
app.post('/api/auth/reset-password',asyncRoute(async(req,res)=>{
 const token=String(req.body.token||''),password=String(req.body.password||'');
 if(!token) return res.status(400).json({error:'Reset link is invalid'});
 if(password.length<8) return res.status(400).json({error:'Password must be at least 8 characters'});
 const r=(await query('select * from password_resets where token_hash=$1 and consumed_at is null and expires_at>now()',[sha256(token)])).rows[0];
 if(!r) return res.status(400).json({error:'This reset link is invalid or has expired. Please request a new one.'});
 const ph=await bcrypt.hash(password,12);
 await query('update users set password_hash=$1 where id=$2',[ph,r.user_id]);
 await query('update password_resets set consumed_at=now() where user_id=$1 and consumed_at is null',[r.user_id]);
 res.json({ok:true,message:'Password updated. You can now log in with your new password.'});
}));
app.get('/api/me',requireAuth,asyncRoute(async(req,res)=>{const u=(await query('select * from users where id=$1',[req.user.sub])).rows[0];res.json({user:cleanUser(u)});}));
app.get('/api/requests',requireAuth,asyncRoute(async(req,res)=>{const rows=(await query(`select r.*,u.full_name requester_name,h.full_name helper_name,h.trust_score helper_trust_score from requests r join users u on u.id=r.requester_id left join users h on h.id=r.helper_id where not exists (select 1 from request_rejections rr where rr.request_id=r.id and rr.user_id=$1) order by r.created_at desc`,[req.user.sub])).rows;res.json(rows);}));
app.post('/api/requests',requireAuth,asyncRoute(async(req,res)=>{
 const {title,description,category,pickupLocation,dropLocation,reward,deliveryMode,quantity,urgent,destinationLat,destinationLng,mapsUrl}=req.body;
 if(!title||!description||!dropLocation) return res.status(400).json({error:'Item, details and drop location are required'});
 const mode=deliveryMode==='off_campus'?'off_campus':'in_campus', qty=Math.max(1,Math.min(999,Number(quantity)||1));
 const base=Number(process.env.BASE_DELIVERY_REWARD||30), urgentExtra=Number(process.env.URGENT_DELIVERY_EXTRA||20);
 const computedReward=String(Math.max(0,base+(urgent?urgentExtra:0)));
 const r=(await query(`insert into requests(requester_id,title,description,category,pickup_location,drop_location,reward,delivery_mode,quantity,urgent,destination_lat,destination_lng,maps_url)
 values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) returning *`,
 [req.user.sub,title,description,category||mode,pickupLocation||null,dropLocation, reward||computedReward,mode,qty,!!urgent,destinationLat??null,destinationLng??null,mapsUrl||null])).rows[0];
 res.status(201).json(r);
}));
app.post('/api/requests/:id/reject',requireAuth,asyncRoute(async(req,res)=>{await query('insert into request_rejections(request_id,user_id) values($1,$2) on conflict do nothing',[req.params.id,req.user.sub]);res.json({ok:true});}));
app.patch('/api/requests/:id/accept',requireAuth,asyncRoute(async(req,res)=>{const r=(await query("update requests set helper_id=$1,status='accepted' where id=$2 and status='open' and requester_id<>$1 returning *",[req.user.sub,req.params.id])).rows[0];if(!r)return res.status(409).json({error:'Request unavailable'});await query('insert into notifications(user_id,message) values($1,$2)',[r.requester_id,`${req.user.name} accepted your request`]);res.json(r);}));
app.patch('/api/requests/:id/status',requireAuth,asyncRoute(async(req,res)=>{const allowed=['picked_up','delivered','cancelled'];if(!allowed.includes(req.body.status))return res.status(400).json({error:'Invalid status'});const r=(await query('update requests set status=$1 where id=$2 and (requester_id=$3 or helper_id=$3) returning *',[req.body.status,req.params.id,req.user.sub])).rows[0];if(!r)return res.status(404).json({error:'Not found'});if(req.body.status==='delivered'&&r.helper_id)await query('update users set trust_score=least(100,trust_score+2) where id=$1',[r.helper_id]);if(req.body.status==='cancelled'&&r.helper_id)await query('update users set trust_score=greatest(20,trust_score-4) where id=$1',[r.helper_id]);res.json(r);}));
app.get('/api/outings',requireAuth,asyncRoute(async(req,res)=>res.json((await query(`select o.*,u.full_name from outings o join users u on u.id=o.user_id where o.stop_at>now() order by o.leaving_at`)).rows)));
app.post('/api/outings',requireAuth,asyncRoute(async(req,res)=>{
 const {destination,leavingAt,stopAt,note}=req.body;
 if(!destination||!leavingAt||!stopAt||new Date(stopAt)<=new Date(leavingAt)) return res.status(400).json({error:'Destination, start time and a stop time later than start are required'});
 if(!String(note||'').trim()) return res.status(400).json({error:'Add a note before saving the outing'});
 const r=(await query('insert into outings(user_id,destination,leaving_at,stop_at,note,active) values($1,$2,$3,$4,$5,true) returning *',[req.user.sub,destination,leavingAt,stopAt,note])).rows[0];
 res.status(201).json(r);
}));
app.get('/api/community',requireAuth,asyncRoute(async(req,res)=>{const posts=(await query(`select p.*,u.full_name author_name from community_posts p join users u on u.id=p.author_id order by p.created_at desc`)).rows;const replies=(await query(`select r.*,u.full_name author_name from community_replies r join users u on u.id=r.author_id order by r.created_at`)).rows;res.json(posts.map(p=>({...p,replies:replies.filter(r=>r.post_id===p.id)})));}));
app.post('/api/community',requireAuth,asyncRoute(async(req,res)=>{const r=(await query('insert into community_posts(author_id,body) values($1,$2) returning *',[req.user.sub,req.body.body])).rows[0];res.status(201).json(r);}));
app.post('/api/community/:id/replies',requireAuth,asyncRoute(async(req,res)=>{const r=(await query('insert into community_replies(post_id,author_id,body) values($1,$2,$3) returning *',[req.params.id,req.user.sub,req.body.body])).rows[0];res.status(201).json(r);}));
app.get('/api/notifications',requireAuth,asyncRoute(async(req,res)=>res.json((await query('select * from notifications where user_id=$1 order by created_at desc limit 50',[req.user.sub])).rows)));
app.get('/api/admin/overview',requireAuth,requireAdmin,asyncRoute(async(req,res)=>{const [users,requests,outings,posts,logins]=await Promise.all([query('select id,full_name,email,room,phone_number,alternate_phone,trust_score,role,is_verified,created_at from users order by created_at desc'),query('select * from requests order by created_at desc'),query('select * from outings order by created_at desc'),query('select * from community_posts order by created_at desc'),query('select * from login_events order by created_at desc limit 250')]);res.json({users:users.rows,requests:requests.rows,outings:outings.rows,posts:posts.rows,logins:logins.rows});}));
app.get('/api/events',requireAuth,asyncRoute(async(req,res)=>{res.set({'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive'});res.flushHeaders();const send=d=>res.write(`data: ${JSON.stringify(d)}\n\n`);send({type:'connected'});const listener=await createListener(d=>send({type:'db-change',...d}));const ping=setInterval(()=>res.write(': ping\n\n'),25000);req.on('close',()=>{clearInterval(ping);listener.end();});}));
app.use((err,req,res,next)=>{console.error(err);if(err.code==='23505')return res.status(409).json({error:'That email already has an account'});res.status(500).json({error:'Server error'});});
async function seedAdmin(){if(!process.env.ADMIN_EMAIL||!process.env.ADMIN_PASSWORD)return;const email=process.env.ADMIN_EMAIL.toLowerCase();const exists=(await query('select id from users where email=$1',[email])).rows[0];if(!exists){const ph=await bcrypt.hash(process.env.ADMIN_PASSWORD,12);await query(`insert into users(full_name,email,room,password_hash,role,is_verified) values('LAZUP Admin',$1,'Admin',$2,'admin',true)`,[email,ph]);}}
const port=Number(process.env.PORT||4000);ensureResetTable().then(ensureFeatureSchema).then(seedAdmin).then(()=>app.listen(port,()=>console.log(`LAZUP API http://localhost:${port}`))).catch(e=>{console.error('Startup failed',e);process.exit(1)});
