# LAZUP Full Stack — React + Express + PostgreSQL

This is the updated LAZUP campus-help application. The browser UI is React; application rules and authentication are in Express; permanent records are stored in PostgreSQL.

## Services
- React: `http://localhost:5173`
- Express API: `http://localhost:4000`; health check: `http://localhost:4000/api/health`
- PostgreSQL protocol: `localhost:5432` (not a browser webpage)
- Adminer database UI (dashboard bundle only): `http://localhost:8080`

## Start
1. Open Docker Desktop and wait for **Engine running**.
2. From this folder run `docker compose up -d` (or `docker compose up -d db` for the core bundle without Adminer).
3. In terminal 1: `cd backend` then `npm.cmd install` then `npm.cmd run dev`.
4. In terminal 2: `cd frontend` then `npm.cmd install` then `npm.cmd run dev`.
5. Open `http://localhost:5173`.

Use `npm.cmd` in PowerShell if the `npm.ps1` execution-policy message appears.

## Registration / OTP setup
- Email registration remains restricted by the backend to `@bl.students.amrita.edu`; the UI wording says an Amrita student email ID is mandatory.
- Email OTP uses EmailJS. Keep the EmailJS Private Key only in `backend/.env`; the backend sends it as `accessToken`. Do not place it in frontend files.
- Phone numbers should be entered in international format, e.g. `+919876543210`. Primary and alternate phone numbers must differ.
- Restart backend after changing `.env`.

## Locations

## Delivery and outings
- Request categories: in-campus and off-campus.
- Quantity, urgency, pickup/drop, map search, and computed reward are stored through the backend in PostgreSQL.
- Default reward is ₹30; urgent delivery adds ₹20. Adjust `BASE_DELIVERY_REWARD` / `URGENT_DELIVERY_EXTRA` in backend `.env` and matching `VITE_` variables in frontend `.env` to keep display and backend calculation aligned.
- Outings require destination, start time, stop time, and a note. The Save button is enabled only when required values are present. Active outings appear between start and stop time.
- Trust score starts at 80/100 for new users, increases by 2 after a completed delivery, and drops by 4 when a request is cancelled after assignment. This is an initial transparent rule-based score, not a validated reputation model. Ratings can be incorporated later.
- The app does not seed fake duplicate trust records; it displays actual PostgreSQL data.

## Schema migration

## Adminer login
For the Docker-based Adminer service:
- System: PostgreSQL
- Server: `db`
- Username: `lazup`
- Password: `lazup_dev_password`
- Database: `lazup`

## Keep your data
Do not run `docker compose down -v` unless you deliberately want to delete the database volume. `docker compose stop` stops services without deleting database data.


## Recent fixes
- Browse requests now also shows your own open requests, marked as `Your request`; other students can see them and accept only requests they did not create.
- Request form supports multiple items using **Add item**. Each item is saved as its own request with its quantity, pickup/drop locations, urgency, and reward.
- Upcoming outings appear immediately after saving, as long as their stop time is in the future.
