const BASE=import.meta.env.VITE_API_URL||'http://localhost:4000/api';
let token=localStorage.getItem('lazup_token')||'';
export const setToken=t=>{token=t||'';t?localStorage.setItem('lazup_token',t):localStorage.removeItem('lazup_token')};
export async function api(path,options={}){const r=await fetch(BASE+path,{...options,headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{}) ,...options.headers}});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.error||'Request failed');return data;}
export const hasToken=()=>!!token;
export function events(onChange){if(!token)return()=>{};const es=new EventSource(`${BASE}/events?token=${encodeURIComponent(token)}`);return()=>es.close();}
