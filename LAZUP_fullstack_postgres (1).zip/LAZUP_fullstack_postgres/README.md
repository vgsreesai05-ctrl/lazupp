# LAZUP Full-Stack — React + Express + PostgreSQL

This project replaces browser/localStorage persistence with a PostgreSQL backend. The frontend is editable React source and all student/admin data is read/written through the API.

## Architecture
- `frontend/` — React 19 + Vite UI
- `backend/` — Express REST API, JWT authentication, role authorization, EmailJS OTP sender
- `backend/sql/schema.sql` — PostgreSQL schema, indexes and `LISTEN/NOTIFY` triggers
- `docker-compose.yml` — PostgreSQL 16 for local development

## Start in VS Code
1. Open the `LAZUP_fullstack_postgres` folder in VS Code.
2. Install Docker Desktop and Node.js 20+.
3. Copy/edit `backend/.env` and **change `JWT_SECRET` and `ADMIN_PASSWORD` before sharing/deploying**.
4. Start PostgreSQL: `docker compose up -d db`
5. In terminal 1: `cd backend && npm install && npm run dev`
6. In terminal 2: `cd frontend && npm install && npm run dev`
7. Open `http://localhost:5173`.

## PostgreSQL / query login data
With Docker running:
```bash
docker compose exec db psql -U lazup -d lazup
```
Then:
```sql
SELECT id, full_name, email, room, role, created_at FROM users ORDER BY created_at DESC;
SELECT email, success, ip, created_at FROM login_events ORDER BY created_at DESC;
SELECT * FROM login_events WHERE email='bl.en.example@bl.students.amrita.edu' ORDER BY created_at DESC;
SELECT r.title, r.status, u.email AS requester FROM requests r JOIN users u ON u.id=r.requester_id ORDER BY r.created_at DESC;
```
VS Code can also display the database using a PostgreSQL extension with host `localhost`, port `5432`, database `lazup`, user `lazup`, password `lazup_dev_password` (development defaults from docker-compose).

## Authentication and privacy
- Student registration only accepts `@bl.students.amrita.edu`.
- OTP is generated on the backend, hashed in PostgreSQL, expires after 60 seconds, and is sent through EmailJS using template variable `passcode` and recipient `to_email`.
- Passwords are bcrypt-hashed. Plain passwords and OTPs are never stored.
- Students do not have an endpoint that lists the user database or login history.
- `/api/admin/overview` requires an authenticated JWT whose role is `admin`.
- Login attempts are stored in `login_events` so SQL queries can audit successful/failed logins.

## Show password & Forgot password
- **Eye icon** on every password field (login, register, reset) toggles the password between hidden and visible.
- **Forgot password?** (login page) -> enter your registered email -> a reset link is emailed through EmailJS -> click the link in that email -> choose a new password -> you are returned to the login page and can sign in with it.
- Reset links are single-use, expire after `RESET_TTL_MINUTES` (default 15), and only a SHA-256 hash of the token is stored (table `password_resets`, created automatically on backend start and also in `schema.sql`).
- Set `FRONTEND_URL` in `backend/.env` to the address where the frontend runs (the link in the email points there).
- EmailJS: by default the existing OTP template is reused and the link is placed in `{{passcode}}`. For a nicer email, create a second template containing `{{reset_link}}` (recipient `{{to_email}}`) and put its ID in `EMAILJS_RESET_TEMPLATE_ID`.

## Admin account
The backend creates the admin from `ADMIN_EMAIL` and `ADMIN_PASSWORD` in `backend/.env` on first startup. Change both values before first real use. The admin password is intentionally not hard-coded into the React bundle.

## Real-time behavior
PostgreSQL triggers publish changes through `pg_notify('lazup_changes', ...)`. The backend exposes a Server-Sent Events stream. The current UI also refreshes periodically for resilience; it can be extended to consume the SSE stream for instant targeted refreshes.

## EmailJS template
Configured values are in `backend/.env`. The EmailJS template should use:
- To Email: `{{to_email}}`
- OTP text: `{{passcode}}`

## Production notes
Use managed PostgreSQL, HTTPS, a strong JWT secret, a non-default database password, rate limiting, secure secrets management, backups, and a server-side email provider/API policy appropriate for production. Do not commit `.env`.
