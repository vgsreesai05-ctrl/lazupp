import express from 'express'; import cors from 'cors'; import helmet from 'helmet'; import bcrypt from 'bcryptjs'; import crypto from 'crypto'; import 'dotenv/config';
import {query,createListener} from './db.js'; import {validStudentEmail,sign,requireAuth,requireAdmin} from './auth.js';
const app=express(); app.use(helmet()); app.use(cors({origin:process.env.FRONTEND_ORIGIN?.split(',')||true})); app.use(express.json({limit:'1mb'}));
const cleanUser=u=>({id:u.id,fullName:u.full_name,email:u.email,room:u.room,role:u.role,createdAt:u.created_at});
const asyncRoute=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);
async function sendEmailOtp(email,name,code){
 const r=await fetch('https://api.emailjs.com/api/v1.0/email/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({service_id:process.env.EMAILJS_SERVICE_ID,template_id:process.env.EMAILJS_TEMPLATE_ID,user_id:process.env.EMAILJS_PUBLIC_KEY,template_params:{to_email:email,user_name:name||'Amrita Student',name:name||'Amrita Student',passcode:code,otp_code:code,title:'LAZUP verification code',message:`Your LAZUP OTP is ${code}. It expires in 1 minute.`}})}); if(!r.ok) throw new Error(`EmailJS failed: ${await r.text()}`);
}
app.get('/api/health',asyncRoute(async(req,res)=>{await query('select 1');res.json({ok:true,database:'postgresql'});}));
app.post('/api/auth/send-otp',asyncRoute(async(req,res)=>{const email=String(req.body.email||'').trim().toLowerCase(); if(!validStudentEmail(email)) return res.status(400).json({error:'Use your @bl.students.amrita.edu email'}); const code=String(crypto.randomInt(100000,1000000)); const hash=await bcrypt.hash(code,10); const ttl=Number(process.env.OTP_TTL_SECONDS||60); await query('insert into otp_challenges(email,code_hash,expires_at) values($1,$2,now()+($3||\' seconds\')::interval)',[email,hash,ttl]); await sendEmailOtp(email,req.body.name,code); res.json({ok:true,expiresIn:ttl});}));
app.post('/api/auth/register',asyncRoute(async(req,res)=>{const {name,email:raw,room,password,otp}=req.body,email=String(raw||'').trim().toLowerCase(); if(!validStudentEmail(email)||!name||!room||String(password||'').length<8) return res.status(400).json({error:'Name, room, valid student email and 8+ character password are required'}); const c=(await query('select * from otp_challenges where email=$1 and consumed_at is null and expires_at>now() order by created_at desc limit 1',[email])).rows[0]; if(!c||!(await bcrypt.compare(String(otp||''),c.code_hash))) return res.status(400).json({error:'Invalid or expired OTP'}); await query('update otp_challenges set consumed_at=now() where id=$1',[c.id]); const ph=await bcrypt.hash(password,12); const u=(await query('insert into users(full_name,email,room,password_hash,is_verified) values($1,$2,$3,$4,true) returning *',[name,email,room,ph])).rows[0]; res.status(201).json({token:sign(u),user:cleanUser(u)});}));
app.post('/api/auth/login',asyncRoute(async(req,res)=>{const email=String(req.body.email||'').trim().toLowerCase(); const u=(await query('select * from users where email=$1',[email])).rows[0]; const ok=!!u&&await bcrypt.compare(String(req.body.password||''),u.password_hash); await query('insert into login_events(user_id,email,success,ip,user_agent) values($1,$2,$3,$4,$5)',[u?.id||null,email,ok,req.ip,req.get('user-agent')]); if(!ok)return res.status(401).json({error:'Invalid email or password'}); res.json({token:sign(u),user:cleanUser(u)});}));
// ---- Forgot / reset password ----
const RESET_TTL_MINUTES=Number(process.env.RESET_TTL_MINUTES||15);
const sha256=v=>crypto.createHash('sha256').update(v).digest('hex');
const frontendUrl=()=>(process.env.FRONTEND_URL||process.env.FRONTEND_ORIGIN?.split(',')[0]||'http://localhost:5173').replace(/\/$/,'');
async function ensureResetTable(){await query(`create table if not exists password_resets(id bigserial primary key,user_id uuid not null references users(id) on delete cascade,token_hash text not null unique,expires_at timestamptz not null,consumed_at timestamptz,created_at timestamptz not null default now())`);await query('create index if not exists password_resets_user_idx on password_resets(user_id,created_at desc)');}
async function sendResetEmail(email,name,link){
 const sharedTemplate=!process.env.EMAILJS_RESET_TEMPLATE_ID;
 const r=await fetch('https://api.emailjs.com/api/v1.0/email/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({service_id:process.env.EMAILJS_SERVICE_ID,template_id:process.env.EMAILJS_RESET_TEMPLATE_ID||process.env.EMAILJS_TEMPLATE_ID,user_id:process.env.EMAILJS_PUBLIC_KEY,template_params:{to_email:email,user_name:name||'Amrita Student',name:name||'Amrita Student',reset_link:link,link,title:'Reset your LAZUP password',message:`Click this link to create a new LAZUP password (valid for ${RESET_TTL_MINUTES} minutes): ${link}`,passcode:sharedTemplate?link:undefined,otp_code:sharedTemplate?link:undefined}})});
 if(!r.ok) throw new Error(`EmailJS failed: ${await r.text()}`);
}
app.post('/api/auth/forgot-password',asyncRoute(async(req,res)=>{
 const email=String(req.body.email||'').trim().toLowerCase();
 const generic={ok:true,message:'If this email is registered, a password reset link has been sent to it.'};
 if(!email||!email.includes('@')) return res.status(400).json({error:'Enter your registered email'});
 const u=(await query('select id,full_name,email from users where email=$1',[email])).rows[0];
 if(!u) return res.json(generic);
 const recent=(await query("select 1 from password_resets where user_id=$1 and created_at>now()-interval '60 seconds' limit 1",[u.id])).rows[0];
 if(recent) return res.status(429).json({error:'A reset email was just sent. Please wait a minute before trying again.'});
 const token=crypto.randomBytes(32).toString('hex');
 await query('update password_resets set consumed_at=now() where user_id=$1 and consumed_at is null',[u.id]);
 await query("insert into password_resets(user_id,token_hash,expires_at) values($1,$2,now()+($3||' minutes')::interval)",[u.id,sha256(token),RESET_TTL_MINUTES]);
 const link=`${frontendUrl()}/?reset_token=${token}`;
 try{await sendResetEmail(u.email,u.full_name,link);}catch(e){console.error(e);return res.status(502).json({error:'Could not send the reset email. Please try again shortly.'});}
 res.json(generic);
}));
app.post('/api/auth/reset-password',asyncRoute(async(req,res)=>{
 const token=String(req.body.token||''),password=String(req.body.password||'');
 if(!token) return res.status(400).json({error:'Reset link is invalid'});
 if(password.length<8) return res.status(400).json({error:'Password must be at least 8 characters'});
 const r=(await query('select * from password_resets where token_hash=$1 and consumed_at is null and expires_at>now()',[sha256(token)])).rows[0];
 if(!r) return res.status(400).json({error:'This reset link is invalid or has expired. Please request a new one.'});
 const ph=await bcrypt.hash(password,12);
 await query('update users set password_hash=$1 where id=$2',[ph,r.user_id]);
 await query('update password_resets set consumed_at=now() where user_id=$1 and consumed_at is null',[r.user_id]);
 res.json({ok:true,message:'Password updated. You can now log in with your new password.'});
}));
app.get('/api/me',requireAuth,asyncRoute(async(req,res)=>{const u=(await query('select * from users where id=$1',[req.user.sub])).rows[0];res.json({user:cleanUser(u)});}));
app.get('/api/requests',requireAuth,asyncRoute(async(req,res)=>{const rows=(await query(`select r.*,u.full_name requester_name,h.full_name helper_name from requests r join users u on u.id=r.requester_id left join users h on h.id=r.helper_id order by r.created_at desc`)).rows;res.json(rows);}));
app.post('/api/requests',requireAuth,asyncRoute(async(req,res)=>{const {title,description,category,pickupLocation,dropLocation,reward}=req.body;const r=(await query('insert into requests(requester_id,title,description,category,pickup_location,drop_location,reward) values($1,$2,$3,$4,$5,$6,$7) returning *',[req.user.sub,title,description,category,pickupLocation,dropLocation,reward])).rows[0];res.status(201).json(r);}));
app.patch('/api/requests/:id/accept',requireAuth,asyncRoute(async(req,res)=>{const r=(await query("update requests set helper_id=$1,status='accepted' where id=$2 and status='open' and requester_id<>$1 returning *",[req.user.sub,req.params.id])).rows[0];if(!r)return res.status(409).json({error:'Request unavailable'});await query('insert into notifications(user_id,message) values($1,$2)',[r.requester_id,`${req.user.name} accepted your request`]);res.json(r);}));
app.patch('/api/requests/:id/status',requireAuth,asyncRoute(async(req,res)=>{const allowed=['picked_up','delivered','cancelled'];if(!allowed.includes(req.body.status))return res.status(400).json({error:'Invalid status'});const r=(await query('update requests set status=$1 where id=$2 and (requester_id=$3 or helper_id=$3) returning *',[req.body.status,req.params.id,req.user.sub])).rows[0];if(!r)return res.status(404).json({error:'Not found'});res.json(r);}));
app.get('/api/outings',requireAuth,asyncRoute(async(req,res)=>res.json((await query(`select o.*,u.full_name from outings o join users u on u.id=o.user_id where o.active=true and o.leaving_at>now()-interval '2 hours' order by o.leaving_at`)).rows)));
app.post('/api/outings',requireAuth,asyncRoute(async(req,res)=>{const r=(await query('insert into outings(user_id,destination,leaving_at,note) values($1,$2,$3,$4) returning *',[req.user.sub,req.body.destination,req.body.leavingAt,req.body.note])).rows[0];res.status(201).json(r);}));
app.get('/api/community',requireAuth,asyncRoute(async(req,res)=>{const posts=(await query(`select p.*,u.full_name author_name from community_posts p join users u on u.id=p.author_id order by p.created_at desc`)).rows;const replies=(await query(`select r.*,u.full_name author_name from community_replies r join users u on u.id=r.author_id order by r.created_at`)).rows;res.json(posts.map(p=>({...p,replies:replies.filter(r=>r.post_id===p.id)})));}));
app.post('/api/community',requireAuth,asyncRoute(async(req,res)=>{const r=(await query('insert into community_posts(author_id,body) values($1,$2) returning *',[req.user.sub,req.body.body])).rows[0];res.status(201).json(r);}));
app.post('/api/community/:id/replies',requireAuth,asyncRoute(async(req,res)=>{const r=(await query('insert into community_replies(post_id,author_id,body) values($1,$2,$3) returning *',[req.params.id,req.user.sub,req.body.body])).rows[0];res.status(201).json(r);}));
app.get('/api/notifications',requireAuth,asyncRoute(async(req,res)=>res.json((await query('select * from notifications where user_id=$1 order by created_at desc limit 50',[req.user.sub])).rows)));
app.get('/api/admin/overview',requireAuth,requireAdmin,asyncRoute(async(req,res)=>{const [users,requests,outings,posts,logins]=await Promise.all([query('select id,full_name,email,room,role,is_verified,created_at from users order by created_at desc'),query('select * from requests order by created_at desc'),query('select * from outings order by created_at desc'),query('select * from community_posts order by created_at desc'),query('select * from login_events order by created_at desc limit 250')]);res.json({users:users.rows,requests:requests.rows,outings:outings.rows,posts:posts.rows,logins:logins.rows});}));
app.get('/api/events',requireAuth,asyncRoute(async(req,res)=>{res.set({'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive'});res.flushHeaders();const send=d=>res.write(`data: ${JSON.stringify(d)}\n\n`);send({type:'connected'});const listener=await createListener(d=>send({type:'db-change',...d}));const ping=setInterval(()=>res.write(': ping\n\n'),25000);req.on('close',()=>{clearInterval(ping);listener.end();});}));
app.use((err,req,res,next)=>{console.error(err);if(err.code==='23505')return res.status(409).json({error:'That email already has an account'});res.status(500).json({error:'Server error'});});
async function seedAdmin(){if(!process.env.ADMIN_EMAIL||!process.env.ADMIN_PASSWORD)return;const email=process.env.ADMIN_EMAIL.toLowerCase();const exists=(await query('select id from users where email=$1',[email])).rows[0];if(!exists){const ph=await bcrypt.hash(process.env.ADMIN_PASSWORD,12);await query(`insert into users(full_name,email,room,password_hash,role,is_verified) values('LAZUP Admin',$1,'Admin',$2,'admin',true)`,[email,ph]);}}
const port=Number(process.env.PORT||4000);ensureResetTable().then(seedAdmin).then(()=>app.listen(port,()=>console.log(`LAZUP API http://localhost:${port}`))).catch(e=>{console.error('Startup failed',e);process.exit(1)});
